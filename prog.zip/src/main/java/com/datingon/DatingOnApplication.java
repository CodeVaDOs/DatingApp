package com.datingon;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DatingOnApplication {

    public static void main(String[] args) {
        SpringApplication.run(DatingOnApplication.class, args);
    }

}
