package com.datingon.dto.rq;

import lombok.Data;

@Data
public class ChatRoomRequest {
    public Long userId;
}
