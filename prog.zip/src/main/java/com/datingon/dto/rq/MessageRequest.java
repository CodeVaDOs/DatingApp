package com.datingon.dto.rq;

import lombok.Data;

@Data
public class MessageRequest {
    public String body;
}
