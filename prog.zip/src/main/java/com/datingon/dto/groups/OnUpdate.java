package com.datingon.dto.groups;

public interface OnUpdate {
}
