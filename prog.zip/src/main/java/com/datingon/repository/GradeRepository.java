package com.datingon.repository;

import com.datingon.entity.grade.Grade;
import org.springframework.stereotype.Repository;

@Repository
public interface GradeRepository extends RepositoryInterface<Grade>{
}
