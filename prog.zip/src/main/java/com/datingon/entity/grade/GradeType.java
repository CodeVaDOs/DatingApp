package com.datingon.entity.grade;

public enum GradeType {
    LIKE,
    DISLIKE
}
