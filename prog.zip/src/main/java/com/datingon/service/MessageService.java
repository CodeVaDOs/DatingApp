package com.datingon.service;

import com.datingon.entity.chat.Message;
import org.springframework.stereotype.Service;

@Service
public class MessageService extends GeneralService<Message> {
}
